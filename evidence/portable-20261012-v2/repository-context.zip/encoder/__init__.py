"""Pretrained EEG encoder integration."""

