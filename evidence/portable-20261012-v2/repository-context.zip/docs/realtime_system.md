# Phase I real-time system draft

A saved channel-first recording can be replayed through Lab Streaming Layer at
its nominal rate or directly through the deterministic array stream. The causal
ring buffer exposes only received samples. Fixed windows are emitted at configured
stride boundaries and sent to a decoder's `predict_proba` interface.

The confidence gate emits a class only for a unique maximum at or above threshold;
otherwise it emits the explicit neutral state. Accumulated evidence requires three
consistent non-neutral windows and emits one command before latching. Neutral or a
state change resets the evidence. The interface receives only gate and evidence
objects, never raw probability arrays.

The 60-second LSL loopback sent and received all 7,680 samples at 128 Hz. Measured
wall time was 60.243 seconds for a nominal 59.992-second timestamp span, including
the deliberate 0.25-second startup lead. The held-out-subject EEGNet replay path
completed with explicit neutral frames and per-window latency logging.

## Integrated native demonstration

`scripts/run_live_demo.py` connects an actual LSL outlet/inlet to the causal
buffer, CPU EEGNet, confidence gate, accumulated evidence, and a native Windows
Forms command grid. It uses the configured modern PowerShell runtime without
changing execution policies. The grid receives gate decisions, not probability
vectors, and acknowledges each displayed window. The script closes the display
automatically after the rehearsal and saves its own initial/final renders.

This protocol trains on subjects other than A09 only: zero A09 support trials,
zero A09 training or validation trials. The first three available trials per
class from A09 are replayed without repeats at 128 Hz (12 windows, 48 seconds).
The saved Profile A epochs were preprocessed offline; this is not causal online
raw-EEG filtering or live brain control. Boundaries between saved trials are
explicit, and the four-second windows do not cross those boundaries.

The hidden-render rehearsal received all 6,144 samples unchanged and rendered
all 12 windows. Wall time was 48.260 s versus a 47.992 s timestamp span; CPU
processing p95 was 6.327 ms. All decisions abstained at the fixed 0.40 threshold,
so no command was emitted. These are functional transport/gating checks, not
evidence of useful decoding accuracy. No threshold was lowered to force a demo.

The visible rehearsal also passed from clean source commit
`95b93536c7204aa22d2a4d9ab7e03f6aadd39e00`. It received 6,144/6,144 samples and
displayed 12/12 predictions, all neutral. Wall time was 48.254 s (drift 0.262 s),
processing p95 5.245 ms and maximum 6.241 ms. Initial and final native renders
were inspected and were readable without clipping. The complete result and
display receipt are in `runs/live_demo/20260831T022419655475Z/`.

Local completion requires an actual visible rehearsal, a matching
configuration, verified result/receipt/preview hashes, and one display receipt
per decoded window (`evaluation/live_demo_audit.py`). A hidden render alone
cannot satisfy that check. The latest receipt is `runs/live_demo/latest.json`.
Both `scripts/evaluate_gate_b.py` and `scripts/phase1_status.py` now use this same
native-evidence verifier. The legacy array replay's frame list alone cannot
pass Gate B's demonstrator check. This remains a functional integration check,
not an accuracy claim or scientific sign-off.

To rehearse on this laptop, from the project folder:

```powershell
.\.venv\Scripts\python.exe scripts/run_live_demo.py
```

Processing latency includes the ready-window copy, prediction and decision logic.
It excludes acquisition of the four-second window, file handoff and native screen
paint. Display acknowledgments are separately timestamped. CPU fallback on the
same laptop is not a substitute for testing a second physical machine.

## Calibration diagnostics utility

`evaluation/calibration_plot.py` plots reliability bins and the accuracy–coverage
curve from probability vectors plus evaluation labels. Empty bins and selections
with zero coverage are omitted, not represented as zero accuracy. This utility
does not fit calibration or tune a decision threshold. The hand-worked synthetic
rendering check is `runs/calibration_smoke/reliability_and_coverage.png`, with
its inputs, numeric expectations and image hash in the companion JSON record.
It is explicitly not an EEG calibration result. Existing benchmark records store
ECE and a selected coverage point but not full probability vectors; empirical
reliability diagrams cannot honestly be recovered from those scalar records.
