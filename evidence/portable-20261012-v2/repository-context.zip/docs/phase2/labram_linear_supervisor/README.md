# Prospective one-case LaBraM linear supervisor

Status on 7 October: the new local
[package](../../../runs/coordination/labram_linear_supervision_20261007_v1/)
has current source/peer bindings and a finite **2026-10-07T14:30:00Z** deadline.
It passed 131 native checks, including 72 extracted acceptance fixtures, and
isolated AST/compile of three generated Python targets under separately
reviewed and accepted scopes. Physical exits and scope releases are recorded.
Different-root reviews passed 394 package checks and 40 saved syntax-result
checks; root [acceptance](../../../runs/coordination/session_20261007_resume/package_root_acceptance_001.json)
certifies preparation and limited checks only.
The saved controls require a current-source refresh; observed RAM is below
the 10 GiB heavy startup floor. There is no execution release or LaBraM result.
Use the [current handoff](../../../HANDOFF.md) and
[prerequisite runbook](prerequisite_runbook.md).

Historical status on 6 October: the 5 October package passed its bounded checks and the
preparation phase closed, with explicit scope releases. The local v3 deadline
**2026-10-05T22:40:00Z has expired**. Preserve its files and receipts; use the
recipes below to create a fresh package with current source, peer and finite
future deadline bindings, then validate/audit the new bytes under fresh
coordination. No historical grant, fixture pass or publication admits new
execution. The [current handoff](../../../HANDOFF.md) and
[prerequisite runbook](prerequisite_runbook.md) govern the next steps.

`Build-LabramLinearPackage.ps1` creates a reproducible operational successor
for **Cho 2017 / LaBraM linear / subject_01 / seed 11 / five shots / repetition 1**.
It constructs five files from byte-pinned historical V10 originals: `parent.py`,
`child.py`, `design.json`, `Invoke-FirstCaseSupervisorV1.ps1` and
`Prepare-FirstCaseRuntimeV1.ps1`. The historical package, V11 template, accepted
EEGNet cell, raw data and checkpoint remain unchanged. No historical runtime
record, prerequisite board, admission or release is copied.

The builder requires `-OutputDirectory`, `-SourceSha256`, `-SourceFileCount`,
`-DeadlineUtc` and `-PeerThreadId`; `-ProjectRoot` defaults to this checkout.
All paths must be absolute ordinary local paths. Output must be a new direct
child of `runs/coordination` with an ASCII basename of at most 64 characters.
That layout retains the operational Python scripts' `ROOT.parents[3]` contract.
Reparse paths, short-name aliases and hard-linked input files are refused.
An existing or interrupted partial directory is preserved and cannot be reused.
The directory's `.gitattributes` disables text conversion for these PowerShell
recipes so Git preserves the exact audited bytes despite global CRLF settings.

The source digest and file count are **declared bindings**, not a source audit
performed by the builder. Supply a separately settled current canonical source.
The UTC deadline accepts exactly `yyyy-MM-ddTHH:mm:ssZ` and becomes a finite
guard in the native launcher, Python supervisor and release contract. It grants
no compute lease or execution permission. The lowercase peer UUID binds the
future explicit response expected by both supervisors; it is not itself a
response. Historical source and peer identities are refused.

```powershell
# Substitute independently settled source, count, deadline and peer values.
# Use a new direct output directory for every construction attempt.
& ./docs/phase2/labram_linear_supervisor/Build-LabramLinearPackage.ps1 `
    -OutputDirectory 'D:\Aenv\pro3\runs\coordination\labram_linear_supervision_fresh' `
    -SourceSha256 $SettledSourceSha256 -SourceFileCount $SettledSourceFileCount `
    -DeadlineUtc $FiniteDeadlineUtc -PeerThreadId $CurrentPeerThreadId
```

The native builder independently computes the case ID from compact sorted JSON:

```json
{"dataset":"cho2017","method":"labram_linear","model_seed":11,"repetition":1,"shots_per_class":5,"target_subject":"subject_01"}
```

Its SHA-256 must be
`af0f24764e577f2223db4759582852aacc2b1b2b0b0a549f1d4b43f8f14998b5`.
This reproduces `config_digest(asdict(CasePlan(...)))` without importing Python.
The separate recorder **cell identity intentionally excludes repetition and
attempts**. Canonical-state refusal covers the new case ID and method identity;
an existing claim, intent, success or matching cell requires deliberate recovery,
never an implicit retry. The child CLI uses the fixed LaBraM method and fresh
worker `cho-labram-linear-20261005-v1`; its recorder verifies that same CasePlan.

Evaluate the generated package with the separate native validator, using a
fresh receipt path under `runs/coordination` and a separately coordinated slot:

```powershell
& ./docs/phase2/labram_linear_supervisor/Test-PackageContract.ps1 `
    -PackageDirectory 'D:\Aenv\pro3\runs\coordination\labram_linear_supervision_fresh' `
    -OutputPath 'D:\Aenv\pro3\runs\coordination\fresh_contract_receipt.json'
```

On 5 October at 19:16 UTC, the local v3 package passed **131 checks**, including
**72 actual AST-extracted acceptance fixtures**. Its native physical witness
records exit0, 1.876 seconds and owned PID absence. At 19:18 UTC, a separately
coordinated direct-base `-I -S -B` check parsed and compiled the generated
parent, child and raw verifier; it executed none of their code. The
[independent audit](../../../runs/coordination/labram_linear_prep_20261005_v1/package_static_independent_audit_001.json)
accepts static/bounded fixture scope, zero blockers. That local evidence binds
the exact recipes and generated bytes; neither the current quality pass nor
these fixtures certify whole launcher/parent interoperability or a real case.
The [prerequisite runbook](prerequisite_runbook.md) gives the remaining order.

`Build-RawVerifier.ps1` separately generates fresh raw-verifier code from a
byte-pinned historical input, with three reversible edits and honest decoding
scope. Its generated code has not performed raw verification. The historical
inputs and local receipts needed by both builders are excluded from Git;
the published recipes alone are not a self-contained runtime release.

Every substitution has an exact occurrence count and appears in the fresh
`package_build_provenance.json`. Reverse substitutions must reconstruct the
original bytes. Latin-1 byte mapping preserves all untouched line endings,
BOM state and trailing newlines. Provenance records each input/output SHA,
byte length, replacement and the declared case/source/deadline/peer binding.
The five pinned originals use LF line endings. Authored replacement literals
are normalized to LF before exact matching and insertion; original file bytes
are never normalized. This also keeps Windows recipe checkout line endings
from changing multiline replacement semantics.
The builder refuses stale operational tokens and rechecks all input bytes before
and during write-once output publication. A failed build may leave a partial
directory, which remains evidence; the script contains no deletion or rollback.
Stable descriptor checks retain volume/file identity, link count, size,
attributes, creation time and last-write time. Access time is excluded because
an ordinary read can legitimately update it.

The package incorporates V11's terminal completion repair and corrected
process/aggregate memory descriptions. The new native terminal condition also
requires ordinary JSON objects, exactly six case properties, string dataset,
method and subject, and actual integer seed/shots/repetition/`measured` values.
Numeric strings, booleans, floating-point values and malformed containers refuse
acceptance. Historical V11 retains its own unchanged predicate semantics.

Legacy `pro3_first_case_*_v1` schemas and `runs/phase2/first_case_supervision`
attempt roots are retained for compatibility with the existing board and recorder
APIs. Here, “first_case” means the compatible single-case supervision contract;
the new method, canonical case, fresh package hashes and one-use release identify
this successor. It cannot authorize or rerun the accepted EEGNet cell. Runtime
preparer source-count metadata is declared rather than measured; the execution
supervisor independently measures and checks both canonical digest and count.

The atomic suspended-create Job adapter is unchanged. Its queried 6 GiB process
and 7.5 GiB aggregate caps, 10 GiB startup RAM floor sampled twice, 4 GiB active
RAM floor, 20 GiB disk floor and 5.5 GiB separate analysis cap remain intact.
The execute budgets remain 480 seconds per inner attempt, 520 seconds per inner
session and 600 seconds for the outer supervisor, with the existing 20-second
cleanup reserve and physical-exit requirements. Environment preparation remains
120 seconds. No automatic cap increase, retry, deadline or lease extension occurs.

Building or evaluating an extracted predicate establishes package/contract scope
only. It imports no numerical library, launches no Python process or Job, reads
no signal or checkpoint bytes, produces no runtime/environment measurement and
creates no release. Full Python/native stdout handling and real supervision are
unexecuted until a separately coordinated runtime validation. The original
nonempty parent success output remains part of the pinned implementation;
an inert extracted-condition pass cannot certify that whole process boundary.

Before a real case, root must independently audit the generated bytes, settle
current source and Git, refresh the environment and prerequisites, verify current
quality plus controls 45/36 and raw evidence, and obtain a fresh scoped compute
response/release and new attempt paths. Bind the actual controls36 writer's
immutable execution receipt rather than a mutable session ledger. Startup
resource floors and final physical cleanup remain mandatory. A source-only
peer response cannot admit numerical validation or the actual case.

The checkpoint's pretraining cohort remains **unverified**. The design marks
runtime/environment measurements pending and no execution authority present.
Scientific Gate A and the experiment freeze remain unsigned; engineering
delegation or a future successful cell signs neither one. This package is not
scientific validation, performance evidence or permission for a broad sweep.
