"""Episodic adaptation methods."""

